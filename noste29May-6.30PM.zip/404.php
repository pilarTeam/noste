<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package noste
 */

get_header();
?>

	<main id="primary" class="site-main">
		<h2>OOPS...</h2>
	</main><!-- #main -->

<?php
get_footer();
